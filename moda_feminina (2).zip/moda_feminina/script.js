(function() {
  // ----- PRODUTOS COM TODAS AS INFORMAÇÕES E IMAGENS -----
  const produtos = [
    {
      id: 1,
      nome: 'Vestido lindo azul',
      preco: 89.99,
      categoria: 'vestidos',
      cor: 'azul',
      tamanho: ['P','M','G'],
      imagem: 'Vestido lindo azul.jpg',
      descricao: 'Tecido: viscose leve · Forro 100% algodão',
      cores: ['Azul', 'Branco'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },
    {
      id: 2,
      nome: 'Vestido longo verde',
      preco: 99.99,
      categoria: 'vestidos',
      cor: 'verde',
      tamanho: ['M','G','GG'],
      imagem: 'Vestido verde longo.jpg',
      descricao: 'Tecido: crepe · Forro 100% poliéster',
      cores: ['Verde', 'Preto'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },
    {
      id: 3,
      nome: 'Vestido Florido',
      preco: 79.99,
      categoria: 'vestidos',
      cor: 'rosa',
      tamanho: ['P','M','G'],
      imagem: 'Vestido florido.jpg',
      descricao: 'Tecido: algodão · Estampa floral',
      cores: ['Rosa', 'Branco'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },
    {
      id: 4,
      nome: 'Vestido Estampa Tropical',
      preco: 109.99,
      categoria: 'vestidos',
      cor: 'branco',
      tamanho: ['M','G'],
      imagem: 'Vestido tropical.jpg',
      descricao: 'Tecido: viscose · Estampa tropical',
      cores: ['Branco', 'Verde'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },
    {
      id: 5,
      nome: 'Vestido Midi Rosa',
      preco: 69.99,
      categoria: 'vestidos',
      cor: 'rosa',
      tamanho: ['PP','P','M'],
      imagem: 'Vestido middie rosa.jpg',
      descricao: 'Tecido: crepe · Midi',
      cores: ['Rosa', 'Preto'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },
    {
      id: 6,
      nome: 'Vestido Longo Estampa',
      preco: 129.99,
      categoria: 'vestidos',
      cor: 'preto',
      tamanho: ['M','G','GG'],
      imagem: 'Vestido estampado.jpg',
      descricao: 'Tecido: poliéster · Estampa geométrica',
      cores: ['Preto', 'Branco'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },
    {
      id: 7,
      nome: 'Vestido Babado',
      preco: 94.99,
      categoria: 'vestidos',
      cor: 'branco',
      tamanho: ['P','M','G'],
      imagem: 'Vestido babado.jpg',
      descricao: 'Tecido: algodão · Babado na barra',
      cores: ['Branco', 'Azul'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },

    // ----- BLUSAS -----
    {
      id: 8,
      nome: 'Blusa pretinho básico',
      preco: 44.99,
      categoria: 'blusas',
      cor: 'preto',
      tamanho: ['PP','P','M'],
      imagem: 'Blusa pretinho básico.jpg',
      descricao: 'Tecido: algodão · Básica',
      cores: ['Preto', 'Branco'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },
    {
      id: 9,
      nome: 'Regata marrom',
      preco: 29.99,
      categoria: 'blusas',
      cor: 'marrom',
      tamanho: ['P','M','G'],
      imagem: 'Regata marrom.jpg',
      descricao: 'Tecido: viscose · Regata',
      cores: ['Marrom', 'Preto'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },
    {
      id: 10,
      nome: 'Blusa Cropped Rosa',
      preco: 39.99,
      categoria: 'blusas',
      cor: 'rosa',
      tamanho: ['P','M'],
      imagem: 'Blusa Cropped Rosa.jpg',
      descricao: 'Tecido: algodão · Cropped',
      cores: ['Rosa', 'Branco'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },
    {
      id: 11,
      nome: 'Blusa Manga Longa',
      preco: 54.99,
      categoria: 'blusas',
      cor: 'preto',
      tamanho: ['M','G'],
      imagem: 'Blusa Manga Longa.jpg',
      descricao: 'Tecido: poliéster · Manga longa',
      cores: ['Preto', 'Cinza'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },
    {
      id: 12,
      nome: 'Blusa Transparente',
      preco: 34.99,
      categoria: 'blusas',
      cor: 'branco',
      tamanho: ['P','M','G'],
      imagem: 'Blusa Transparente.jpg',
      descricao: 'Tecido: organza · Transparente',
      cores: ['Branco', 'Preto'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },
    {
      id: 13,
      nome: 'Blusa Tricot',
      preco: 49.99,
      categoria: 'blusas',
      cor: 'bege',
      tamanho: ['M','G'],
      imagem: 'Blusa Tricot.jpg',
      descricao: 'Tecido: tricot · Leve',
      cores: ['Bege', 'Marrom'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },

    // ----- CALÇAS -----
    {
      id: 14,
      nome: 'Calça carregável',
      preco: 129.99,
      categoria: 'calcas',
      cor: 'preto',
      tamanho: ['M','G'],
      imagem: 'Calça carregável.jpg',
      descricao: 'Tecido: sarja · Cargo',
      cores: ['Preto', 'Verde'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },
    {
      id: 15,
      nome: 'Calça Jeans Azul',
      preco: 109.99,
      categoria: 'calcas',
      cor: 'azul',
      tamanho: ['M','G','GG'],
      imagem: 'Calça Jeans Azul.jpg',
      descricao: 'Tecido: denim · Jeans',
      cores: ['Azul', 'Preto'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },
    {
      id: 16,
      nome: 'Calça Pantacourt',
      preco: 99.99,
      categoria: 'calcas',
      cor: 'bege',
      tamanho: ['P','M','G'],
      imagem: 'Calça Pantacourt.jpg',
      descricao: 'Tecido: linho · Pantacourt',
      cores: ['Bege', 'Branco'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },
    {
      id: 17,
      nome: 'Calça Cargo',
      preco: 119.99,
      categoria: 'calcas',
      cor: 'verde',
      tamanho: ['M','G'],
      imagem: 'Calça Cargo.jpg',
      descricao: 'Tecido: sarja · Cargo',
      cores: ['Verde', 'Preto'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },
    {
      id: 18,
      nome: 'Calça Skinny',
      preco: 89.99,
      categoria: 'calcas',
      cor: 'preto',
      tamanho: ['PP','P','M'],
      imagem: 'Skinny.jpg',
      descricao: 'Tecido: elastano · Skinny',
      cores: ['Preto', 'Azul'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },

    // ----- SAIAS -----
    {
      id: 19,
      nome: 'Saia branca de babado',
      preco: 59.99,
      categoria: 'saias',
      cor: 'branco',
      tamanho: ['PP','P','M'],
      imagem: 'Saia branca de babado.jpg',
      descricao: 'Tecido: algodão · Babado',
      cores: ['Branco', 'Preto'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },
    {
      id: 20,
      nome: 'Saia Midi Rosa',
      preco: 69.99,
      categoria: 'saias',
      cor: 'rosa',
      tamanho: ['P','M','G'],
      imagem: 'Saia rosa.jpg',
      descricao: 'Tecido: crepe · Midi',
      cores: ['Rosa', 'Preto'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },
    {
      id: 21,
      nome: 'Saia Lápis',
      preco: 79.99,
      categoria: 'saias',
      cor: 'preto',
      tamanho: ['M','G'],
      imagem: 'Saia Lápis.jpg',
      descricao: 'Tecido: poliéster · Lápis',
      cores: ['Preto', 'Cinza'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },
    {
      id: 22,
      nome: 'Saia Círculo',
      preco: 89.99,
      categoria: 'saias',
      cor: 'azul',
      tamanho: ['P','M','G'],
      imagem: 'Saia Círculo Azul.jpg',
      descricao: 'Tecido: viscose · Círculo',
      cores: ['Azul', 'Branco'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },

    // ----- CONJUNTOS -----
    {
      id: 23,
      nome: 'Conjunto listrado',
      preco: 119.99,
      categoria: 'conjuntos',
      cor: 'branco',
      tamanho: ['M','G'],
      imagem: 'Conjunto listrado.jpg',
      descricao: 'Tecido: algodão · Listrado',
      cores: ['Branco', 'Preto'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },
    {
      id: 24,
      nome: 'Conjunto Blazer + Short',
      preco: 159.99,
      categoria: 'conjuntos',
      cor: 'preto',
      tamanho: ['M','G','GG'],
      imagem: 'Blazer + Short.jpg',
      descricao: 'Tecido: sarja · Blazer e short',
      cores: ['Preto', 'Branco'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },
    {
      id: 25,
      nome: 'Conjunto Cropped + Saia',
      preco: 139.99,
      categoria: 'conjuntos',
      cor: 'rosa',
      tamanho: ['P','M'],
      imagem: 'Conjunto Cropped + Saia.jpg',
      descricao: 'Tecido: viscose · Cropped e saia',
      cores: ['Rosa', 'Preto'],
      medidas: 'PP (32/62), P (34/66), M (36/70), G (38/74), GG (40/78)'
    },

    // ----- ACESSÓRIOS -----
    {
      id: 26,
      nome: 'Calçado preto',
      preco: 59.99,
      categoria: 'acessorios',
      cor: 'preto',
      tamanho: ['P','M'],
      imagem: 'Calçado preto.jpg',
      descricao: 'Material: couro sintético',
      cores: ['Preto', 'Marrom'],
      medidas: 'Números: 34 a 40'
    },
    {
      id: 27,
      nome: 'Bolsa Coringa',
      preco: 49.99,
      categoria: 'acessorios',
      cor: 'marrom',
      tamanho: ['único'],
      imagem: 'Bolsa Coringa.jpg',
      descricao: 'Material: couro · Bolsa transversal',
      cores: ['Marrom', 'Preto'],
      medidas: 'Tamanho único'
    },
    {
      id: 28,
      nome: 'Colar Dourado',
      preco: 29.99,
      categoria: 'acessorios',
      cor: 'dourado',
      tamanho: ['único'],
      imagem: 'Colar Dourado.jpg',
      descricao: 'Material: metal dourado · Colar fino',
      cores: ['Dourado', 'Prata'],
      medidas: 'Tamanho único'
    },
    {
      id: 29,
      nome: 'Sandália Preta',
      preco: 79.99,
      categoria: 'acessorios',
      cor: 'preto',
      tamanho: ['P','M','G'],
      imagem: 'Sandália Preta.jpg',
      descricao: 'Material: couro · Sandália de tira',
      cores: ['Preto', 'Marrom'],
      medidas: 'Números: 34 a 40'
    },
    {
      id: 30,
      nome: 'Bolsa Transparente',
      preco: 39.99,
      categoria: 'acessorios',
      cor: 'branco',
      tamanho: ['único'],
      imagem: 'Bolsa Transparente.jpg',
      descricao: 'Material: PVC · Bolsa transparente',
      cores: ['Branco', 'Preto'],
      medidas: 'Tamanho único'
    },
    {
      id: 31,
      nome: 'Cinto Couro',
      preco: 34.99,
      categoria: 'acessorios',
      cor: 'marrom',
      tamanho: ['único'],
      imagem: 'Cinto Couro.jpg',
      descricao: 'Material: couro · Cinto fino',
      cores: ['Marrom', 'Preto'],
      medidas: 'Tamanhos: P, M, G'
    }
  ];

  // ----- DESTAQUES -----
  const destaque = [
    {
      id: 9,
      nome: 'Regata marrom',
      preco: 29.99,
      imagem: 'Regata marrom.jpg'
    },
    {
      id: 23,
      nome: 'Conjunto listrado',
      preco: 119.99,
      imagem: 'Conjunto listrado.jpg'
    },
    {
      id: 2,
      nome: 'Vestido longo verde',
      preco: 99.99,
      imagem:'Vestido verde longo.jpg'
    },
    {
      id: 6,
      nome: 'Vestido Longo Estampa',
      preco: 129.99,
      imagem: 'Vestido Estampado.jpg'
    },
    {
      id: 27,
      nome: 'Bolsa Coringa',
      preco: 49.99,
      imagem: 'Bolsa Coringa.jpg'
    }
  ];

  // ----- ESTADO -----
  let carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];
  let wishlist = JSON.parse(localStorage.getItem('wishlist')) || [];
  let produtosExibidos = [...produtos];
  let categoriaAtual = 'todos';
  let produtoDetalheAtual = null;

  // ----- ELEMENTOS -----
  const grid = document.getElementById('produtosGrid');
  const destaqueGrid = document.getElementById('destaqueGrid');
  const toast = document.getElementById('toast');
  const carrinhoCount = document.getElementById('carrinhoCount');
  const carrinhoOverlay = document.getElementById('carrinhoOverlay');
  const carrinhoItems = document.getElementById('carrinhoItems');
  const carrinhoTotal = document.getElementById('carrinhoTotal');
  const filtroTamanho = document.getElementById('filtroTamanho');
  const filtroCor = document.getElementById('filtroCor');
  const filtroPreco = document.getElementById('filtroPreco');
  const btnFiltrar = document.getElementById('filtrarBtn');
  const btnLimparFiltros = document.getElementById('limparFiltros');
  const tituloCategoria = document.getElementById('tituloCategoria');
  const resumoItens = document.getElementById('resumoItens');
  const resumoTotal = document.getElementById('resumoTotal');
  const detalheMainImg = document.getElementById('detalheMainImg');

  // ----- TOAST -----
  function mostrarToast(msg) {
    toast.textContent = msg;
    toast.classList.add('mostrar');

    clearTimeout(toast._timeout);

    toast._timeout = setTimeout(() => {
      toast.classList.remove('mostrar');
    }, 2200);
  }

  // ----- CARRINHO -----
  function atualizarCarrinho() {
    const totalItens = carrinho.reduce((acc, i) => acc + i.qtd, 0);

    carrinhoCount.textContent = totalItens;

    localStorage.setItem('carrinho', JSON.stringify(carrinho));

    renderizarCarrinhoSidebar();
    atualizarResumoPagamento();
  }

  function adicionarAoCarrinho(produto) {
    const existente = carrinho.find(i => i.id === produto.id);

    if (existente) {
      existente.qtd++;
    } else {
      carrinho.push({
        ...produto,
        qtd: 1
      });
    }

    atualizarCarrinho();
    mostrarToast('Adicionado ao carrinho');
  }

  function removerDoCarrinho(id) {
    carrinho = carrinho.filter(i => i.id !== id);

    atualizarCarrinho();

    mostrarToast('Removido do carrinho');
  }

  function renderizarCarrinhoSidebar() {
    if (carrinho.length === 0) {
      carrinhoItems.innerHTML =
        '<p style="text-align:center; color:#9a7a84; padding:2rem 0;">Seu carrinho está vazio</p>';

      carrinhoTotal.textContent = 'R$ 0,00';

      return;
    }

    let html = '';
    let total = 0;

    carrinho.forEach(item => {
      total += item.preco * item.qtd;

      html += `
        <div class="carrinho-item">
          <div class="item-info">
            <span class="nome">${item.nome}</span>
            <span class="preco">
              R$ ${item.preco.toFixed(2)} x ${item.qtd}
            </span>
          </div>

          <button class="remove-item" data-id="${item.id}">
            <i class="fas fa-trash-alt"></i>
          </button>
        </div>
      `;
    });

    carrinhoItems.innerHTML = html;

    carrinhoTotal.textContent =
      `R$ ${total.toFixed(2)}`;

    carrinhoItems
      .querySelectorAll('.remove-item')
      .forEach(btn => {
        btn.addEventListener('click', function() {
          removerDoCarrinho(Number(this.dataset.id));
        });
      });
  }

  // ----- RESUMO DO PEDIDO -----
  function atualizarResumoPagamento() {
    if (carrinho.length === 0) {
      resumoItens.innerHTML =
        '<p style="text-align:center; color:#9a7a84; padding:0.5rem 0;">Seu carrinho está vazio</p>';

      resumoTotal.textContent = 'R$ 0,00';

      return;
    }

    let html = '';
    let total = 0;

    carrinho.forEach(item => {
      total += item.preco * item.qtd;

      html += `
        <div class="resumo-item">
          <span>${item.nome} x${item.qtd}</span>
          <span>R$ ${(item.preco * item.qtd).toFixed(2)}</span>
        </div>
      `;
    });

    const frete = total > 199 ? 0 : 15;

    if (frete > 0) {
      html += `
        <div class="resumo-item">
          <span>Frete</span>
          <span>R$ ${frete.toFixed(2)}</span>
        </div>
      `;
    } else {
      html += `
        <div class="resumo-item" style="color:#4caf50;">
          <span>Frete grátis</span>
          <span>R$ 0,00</span>
        </div>
      `;
    }

    resumoItens.innerHTML = html;

    resumoTotal.textContent =
      `R$ ${(total + frete).toFixed(2)}`;
  }

  // ----- FAVORITOS -----
  function toggleWishlist(id) {
    const index = wishlist.indexOf(id);

    if (index > -1) {
      wishlist.splice(index, 1);
      mostrarToast('Removido dos favoritos');
    } else {
      wishlist.push(id);
      mostrarToast('Adicionado aos favoritos');
    }

    localStorage.setItem(
      'wishlist',
      JSON.stringify(wishlist)
    );

    document
      .querySelectorAll('.fa-heart[data-id]')
      .forEach(icon => {
        const prodId = Number(icon.dataset.id);

        if (wishlist.includes(prodId)) {
          icon.classList.add(
            'wishlist-active',
            'fas'
          );

          icon.classList.remove('far');
        } else {
          icon.classList.remove(
            'wishlist-active',
            'fas'
          );

          icon.classList.add('far');
        }
      });

    if (produtoDetalheAtual) {
      const btnFav =
        document.getElementById('favoritarDetalhe');

      const isFav =
        wishlist.includes(produtoDetalheAtual.id);

      btnFav.innerHTML = isFav
        ? '<i class="fas fa-heart"></i> Favoritado'
        : '<i class="far fa-heart"></i> Favoritar';
    }
  }

  // ----- FILTROS -----
  function aplicarFiltros() {
    const tam = filtroTamanho.value;
    const cor = filtroCor.value.toLowerCase();
    const precoMax =
      parseFloat(filtroPreco.value) || Infinity;

    let lista = produtos;

    if (categoriaAtual !== 'todos') {
      lista = lista.filter(
        p => p.categoria === categoriaAtual
      );
    }

    if (tam) {
      lista = lista.filter(
        p => p.tamanho.includes(tam)
      );
    }

    if (cor) {
      lista = lista.filter(
        p => p.cor === cor
      );
    }

    if (precoMax < Infinity) {
      lista = lista.filter(
        p => p.preco <= precoMax
      );
    }

    produtosExibidos = lista;

    renderProdutos(lista);

    if (categoriaAtual === 'todos') {
      tituloCategoria.textContent =
        'Todos os produtos';
    } else {
      tituloCategoria.textContent =
        `Categoria: ${
          categoriaAtual.charAt(0).toUpperCase() +
          categoriaAtual.slice(1)
        }`;
    }

    if (lista.length === 0) {
      tituloCategoria.textContent =
        'Nenhum produto encontrado';
    }
  }

  function limparFiltros() {
    filtroTamanho.value = '';
    filtroCor.value = '';
    filtroPreco.value = '';

    categoriaAtual = 'todos';
    produtosExibidos = [...produtos];

    renderProdutos(produtos);

    tituloCategoria.textContent =
      'Todos os produtos';

    document
      .querySelectorAll('.nav-link-aba')
      .forEach(link => {
        link.classList.remove('ativa');

        if (link.dataset.aba === 'home') {
          link.classList.add('ativa');
        }
      });

    mostrarToast('Filtros limpos');
  }

  // ----- RENDERIZAR PRODUTOS COM IMAGENS -----
  function renderProdutos(lista = produtos) {
    grid.innerHTML = '';

    lista.forEach((p, index) => {
      const div =
        document.createElement('div');

      div.className = 'produto-item';

      div.style.animationDelay =
        (index * 0.04) + 's';

      const isFav =
        wishlist.includes(p.id);

      div.innerHTML = `
        <div class="produto-img">
          <img
            src="${p.imagem}"
            alt="${p.nome}"
            loading="lazy"
          >
        </div>

        <div class="produto-nome">
          ${p.nome}
        </div>

        <div class="produto-preco">
          R$ ${p.preco.toFixed(2)}
        </div>

        <div class="produto-acoes">

          <i
            class="${isFav ? 'fas wishlist-active' : 'far'} fa-heart"
            data-id="${p.id}">
          </i>

          <i
            class="fas fa-shopping-bag"
            data-id="${p.id}">
          </i>

          <i
            class="fas fa-eye"
            data-id="${p.id}">
          </i>

        </div>
      `;

      grid.appendChild(div);
    });

    grid
      .querySelectorAll('.fa-heart')
      .forEach(btn => {
        btn.addEventListener(
          'click',
          function(e) {
            e.stopPropagation();

            toggleWishlist(
              Number(this.dataset.id)
            );
          }
        );
      });

    grid
      .querySelectorAll('.fa-shopping-bag')
      .forEach(btn => {
        btn.addEventListener(
          'click',
          function() {
            const id =
              Number(this.dataset.id);

            const prod =
              produtos.find(
                p => p.id === id
              );

            if (prod) {
              adicionarAoCarrinho(prod);
            }
          }
        );
      });

    grid
      .querySelectorAll('.fa-eye')
      .forEach(btn => {
        btn.addEventListener(
          'click',
          function() {
            const id =
              Number(this.dataset.id);

            const prod =
              produtos.find(
                p => p.id === id
              );

            if (prod) {
              abrirDetalhe(prod);
            }
          }
        );
      });
  }

  // ----- RENDERIZAR DESTAQUE COM IMAGENS -----
  function renderDestaque() {
    destaqueGrid.innerHTML = '';

    destaque.forEach((d, index) => {
      const div =
        document.createElement('div');

      div.className = 'destaque-item';

      div.style.animationDelay =
        (index * 0.08) + 's';

      div.innerHTML = `
        <div class="thumb">
          <img
            src="${d.imagem}"
            alt="${d.nome}"
            loading="lazy"
          >
        </div>

        <div
          style="
            font-weight:500;
            margin-top:0.3rem;
          "
        >
          ${d.nome}
        </div>

        <div
          style="
            color:#b5838d;
            font-weight:600;
          "
        >
          R$ ${d.preco.toFixed(2)}
        </div>
      `;

      destaqueGrid.appendChild(div);
    });
  }

  // ----- ABRIR DETALHE COM IMAGEM -----
  function abrirDetalhe(produto) {
    produtoDetalheAtual = produto;

    mostrarAba('detalhe');

    detalheMainImg.innerHTML = `
      <img
        src="${produto.imagem}"
        alt="${produto.nome}"
      >
    `;

    document.getElementById(
      'detalheNome'
    ).textContent = produto.nome;

    document.getElementById(
      'detalhePreco'
    ).textContent =
      `R$ ${produto.preco.toFixed(2)}`;

    document.getElementById(
      'detalheDescricao'
    ).innerHTML =
      `<i class="fas fa-tag"></i> ${produto.descricao}`;

    // Tamanhos
    const tamanhosContainer =
      document.getElementById(
        'detalheTamanhos'
      );

    tamanhosContainer.innerHTML = '';

    produto.tamanho.forEach(t => {
      const btn =
        document.createElement('button');

      btn.textContent = t;

      tamanhosContainer.appendChild(btn);
    });

    // Cores
    const coresContainer =
      document.getElementById(
        'detalheCores'
      );

    coresContainer.innerHTML = '';

    produto.cores.forEach(c => {
      const btn =
        document.createElement('button');

      btn.textContent = c;

      coresContainer.appendChild(btn);
    });

    // Medidas
    document.getElementById(
      'detalheMedidas'
    ).innerHTML =
      `<i class="fas fa-ruler"></i>
       Tabela de medidas: ${produto.medidas}`;

    // Favoritar
    const btnFav =
      document.getElementById(
        'favoritarDetalhe'
      );

    const isFav =
      wishlist.includes(produto.id);

    btnFav.innerHTML = isFav
      ? '<i class="fas fa-heart"></i> Favoritado'
      : '<i class="far fa-heart"></i> Favoritar';

    mostrarToast(
      'Detalhes de ' + produto.nome
    );
  }

  // ----- NAVEGAÇÃO ENTRE ABAS -----
  const abas =
    document.querySelectorAll(
      '.nav-link-aba'
    );

  const conteudos = {
    home: document.getElementById(
      'aba-home'
    ),

    detalhe: document.getElementById(
      'aba-detalhe'
    ),

    pagamento: document.getElementById(
      'aba-pagamento'
    )
  };

  function mostrarAba(id) {
    Object.values(conteudos)
      .forEach(el => {
        el.classList.add('oculto');
      });

    if (conteudos[id]) {
      conteudos[id]
        .classList.remove('oculto');
    }

    abas.forEach(link => {
      link.classList.remove('ativa');

      if (link.dataset.aba === id) {
        link.classList.add('ativa');
      }
    });

    carrinhoOverlay
      .classList.remove('aberto');

    document
      .getElementById('loginOverlay')
      .classList.remove('aberto');

    if (id === 'pagamento') {
      atualizarResumoPagamento();
    }
  }

  abas.forEach(link => {
    link.addEventListener(
      'click',
      function(e) {
        e.preventDefault();

        const aba =
          this.dataset.aba;

        if (aba === 'home') {
          categoriaAtual = 'todos';

          limparFiltros();

          mostrarAba('home');

        } else if (
          [
            'vestidos',
            'blusas',
            'calcas',
            'saias',
            'conjuntos',
            'acessorios'
          ].includes(aba)
        ) {
          categoriaAtual = aba;

          mostrarAba('home');

          aplicarFiltros();

          abas.forEach(l =>
            l.classList.remove('ativa')
          );

          this.classList.add('ativa');

        } else if (
          aba === 'pagamento'
        ) {
          mostrarAba('pagamento');
        }
      }
    );
  });

  // ----- CATEGORIAS RODAPÉ -----
  document
    .querySelectorAll(
      '.rodape-link[data-aba]'
    )
    .forEach(link => {
      link.addEventListener(
        'click',
        function(e) {
          e.preventDefault();

          const aba =
            this.dataset.aba;

          if (aba === 'pagamento') {
            mostrarAba('pagamento');
          } else {
            categoriaAtual = aba;

            mostrarAba('home');

            aplicarFiltros();

            abas.forEach(l => {
              l.classList.remove('ativa');

              if (
                l.dataset.aba === aba
              ) {
                l.classList.add('ativa');
              }
            });
          }
        }
      );
    });

  // ----- CATEGORIAS EM DESTAQUE -----
  document
    .querySelectorAll(
      '.categorias-destaque span'
    )
    .forEach(el => {
      el.addEventListener(
        'click',
        function() {
          const cat =
            this.dataset.cat;

          categoriaAtual = cat;

          mostrarAba('home');

          aplicarFiltros();

          abas.forEach(l => {
            l.classList.remove('ativa');

            if (
              l.dataset.aba === cat
            ) {
              l.classList.add('ativa');
            }
          });
        }
      );
    });

  // ----- LOGIN / CADASTRO -----
  const loginOverlay =
    document.getElementById(
      'loginOverlay'
    );

  const loginForm =
    document.getElementById(
      'loginForm'
    );

  const cadastroForm =
    document.getElementById(
      'cadastroForm'
    );

  const toggleAuthLink =
    document.getElementById(
      'toggleAuthLink'
    );

  const loginTitulo =
    document.getElementById(
      'loginTitulo'
    );

  const loginSubtitulo =
    document.getElementById(
      'loginSubtitulo'
    );

  const authMsg =
    document.getElementById(
      'authMsg'
    );

  let isLoginMode = true;

  function toggleAuthMode() {
    isLoginMode = !isLoginMode;

    if (isLoginMode) {
      loginForm.style.display =
        'block';

      cadastroForm.style.display =
        'none';

      loginTitulo.textContent =
        'Floratta';

      loginSubtitulo.textContent =
        'Faça login e encontre os melhores looks';

      toggleAuthLink.textContent =
        'Cadastrar-se';

    } else {
      loginForm.style.display =
        'none';

      cadastroForm.style.display =
        'block';

      loginTitulo.textContent =
        'Crie sua conta';

      loginSubtitulo.textContent =
        'Cadastre-se e comece a comprar';

      toggleAuthLink.textContent =
        'Voltar para o login';
    }

    authMsg.textContent = '';
  }

  document
    .getElementById('loginIcon')
    .addEventListener(
      'click',
      () => {
        loginOverlay.classList.toggle(
          'aberto'
        );

        if (!isLoginMode) {
          toggleAuthMode();
        }
      }
    );

  document
    .getElementById('loginFechar')
    .addEventListener(
      'click',
      () => {
        loginOverlay.classList.remove(
          'aberto'
        );
      }
    );

  loginOverlay.addEventListener(
    'click',
    function(e) {
      if (e.target === this) {
        this.classList.remove(
          'aberto'
        );
      }
    }
  );

  toggleAuthLink.addEventListener(
    'click',
    function(e) {
      e.preventDefault();

      toggleAuthMode();
    }
  );

  loginForm.addEventListener(
    'submit',
    function(e) {
      e.preventDefault();

      const email =
        document.getElementById(
          'loginEmail'
        ).value.trim();

      const senha =
        document.getElementById(
          'loginSenha'
        ).value.trim();

      if (email && senha) {
        authMsg.textContent =
          'Login bem-sucedido! Bem-vinda, ' +
          email;

        authMsg.style.color =
          '#b5838d';

        setTimeout(() => {
          loginOverlay.classList.remove(
            'aberto'
          );

          mostrarToast(
            'Olá, ' + email
          );
        }, 800);

      } else {
        authMsg.textContent =
          'Preencha login e senha';

        authMsg.style.color =
          '#c0392b';
      }
    }
  );

  cadastroForm.addEventListener(
    'submit',
    function(e) {
      e.preventDefault();

      const nome =
        document.getElementById(
          'cadastroNome'
        ).value.trim();

      const email =
        document.getElementById(
          'cadastroEmail'
        ).value.trim();

      const senha =
        document.getElementById(
          'cadastroSenha'
        ).value;

      const senha2 =
        document.getElementById(
          'cadastroSenha2'
        ).value;

      if (
        !nome ||
        !email ||
        !senha ||
        !senha2
      ) {
        authMsg.textContent =
          'Preencha todos os campos';

        authMsg.style.color =
          '#c0392b';

        return;
      }

      if (senha !== senha2) {
        authMsg.textContent =
          'As senhas não coincidem';

        authMsg.style.color =
          '#c0392b';

        return;
      }

      if (senha.length < 6) {
        authMsg.textContent =
          'A senha deve ter pelo menos 6 caracteres';

        authMsg.style.color =
          '#c0392b';

        return;
      }

      authMsg.textContent =
        'Cadastro realizado com sucesso! Agora faça login.';

      authMsg.style.color =
        '#4caf50';

      setTimeout(() => {
        if (!isLoginMode) {
          toggleAuthMode();
        }

        document.getElementById(
          'loginEmail'
        ).value = email;

        authMsg.textContent =
          'Conta criada! Faça login para continuar.';

        authMsg.style.color =
          '#b5838d';

      }, 1000);
    }
  );

  // ----- ÍCONES HEADER -----
  document
    .getElementById('wishlistIcon')
    .addEventListener(
      'click',
      () => {
        const favs =
          produtos.filter(
            p => wishlist.includes(p.id)
          );

        if (favs.length === 0) {
          mostrarToast(
            'Sua wishlist está vazia'
          );

        } else {
          mostrarToast(
            favs.length +
            ' produtos na wishlist'
          );

          categoriaAtual = 'todos';

          mostrarAba('home');

          renderProdutos(favs);

          tituloCategoria.textContent =
            'Meus Favoritos';

          abas.forEach(l =>
            l.classList.remove('ativa')
          );
        }
      }
    );

  document
    .getElementById('carrinhoIcon')
    .addEventListener(
      'click',
      function(e) {
        e.stopPropagation();

        carrinhoOverlay.classList.toggle(
          'aberto'
        );

        renderizarCarrinhoSidebar();
      }
    );

  document
    .getElementById('fecharCarrinho')
    .addEventListener(
      'click',
      () => {
        carrinhoOverlay.classList.remove(
          'aberto'
        );
      }
    );

  carrinhoOverlay.addEventListener(
    'click',
    function(e) {
      if (e.target === this) {
        this.classList.remove(
          'aberto'
        );
      }
    }
  );

  // ----- PAGAMENTO -----
  document
    .getElementById(
      'confirmarPagamento'
    )
    .addEventListener(
      'click',
      function() {
        const num =
          document.getElementById(
            'cardNumber'
          ).value.trim();

        const valid =
          document.getElementById(
            'cardValidade'
          ).value.trim();

        const cvv =
          document.getElementById(
            'cardCvv'
          ).value.trim();

        const nome =
          document.getElementById(
            'cardNome'
          ).value.trim();

        const msg =
          document.getElementById(
            'pagamentoMsg'
          );

        if (
          num.length >= 12 &&
          valid.length >= 4 &&
          cvv.length >= 3 &&
          nome.length > 2
        ) {
          msg.innerHTML =
            'Pagamento confirmado! Pedido #FLO-2026';

          msg.style.color =
            '#4caf50';

          mostrarToast(
            'Pagamento aprovado! Obrigada pela compra.'
          );

          carrinho = [];

          atualizarCarrinho();

        } else {
          msg.innerHTML =
            'Preencha todos os dados do cartão corretamente.';

          msg.style.color =
            '#c0392b';
        }
      }
    );

  document
    .getElementById(
      'cancelarPagamento'
    )
    .addEventListener(
      'click',
      function() {
        document.getElementById(
          'pagamentoMsg'
        ).textContent = '';

        mostrarToast(
          'Pagamento cancelado'
        );
      }
    );

  // ----- DETALHE -----
  document
    .getElementById(
      'comprarAgoraDetalhe'
    )
    .addEventListener(
      'click',
      function() {
        if (produtoDetalheAtual) {
          adicionarAoCarrinho(
            produtoDetalheAtual
          );

          mostrarAba('pagamento');

          mostrarToast(
            'Redirecionando para pagamento'
          );
        }
      }
    );

  document
    .getElementById(
      'addCarrinhoDetalhe'
    )
    .addEventListener(
      'click',
      function() {
        if (produtoDetalheAtual) {
          adicionarAoCarrinho(
            produtoDetalheAtual
          );
        }
      }
    );

  document
    .getElementById(
      'favoritarDetalhe'
    )
    .addEventListener(
      'click',
      function() {
        if (produtoDetalheAtual) {
          toggleWishlist(
            produtoDetalheAtual.id
          );
        }
      }
    );

  // ----- CARROSSEL -----
  let slideIndex = 0;

  const slides =
    document.querySelectorAll(
      '.carousel-slide'
    );

  const dots =
    document.querySelectorAll(
      '.dot'
    );

  const totalSlides =
    slides.length;

  function showSlide(index) {
    if (totalSlides === 0) return;

    if (index < 0) {
      index = totalSlides - 1;
    }

    if (index >= totalSlides) {
      index = 0;
    }

    slideIndex = index;

    document.getElementById(
      'carouselSlides'
    ).style.transform =
      `translateX(${-index * 100}%)`;

    dots.forEach((d, i) => {
      d.classList.toggle(
        'active',
        i === index
      );
    });
  }

  if (
    document.getElementById(
      'carouselPrev'
    )
  ) {
    document
      .getElementById(
        'carouselPrev'
      )
      .addEventListener(
        'click',
        () =>
          showSlide(
            slideIndex - 1
          )
      );
  }

  if (
    document.getElementById(
      'carouselNext'
    )
  ) {
    document
      .getElementById(
        'carouselNext'
      )
      .addEventListener(
        'click',
        () =>
          showSlide(
            slideIndex + 1
          )
      );
  }

  dots.forEach(dot => {
    dot.addEventListener(
      'click',
      function() {
        showSlide(
          Number(
            this.dataset.index
          )
        );
      }
    );
  });

  if (totalSlides > 0) {
    setInterval(
      () =>
        showSlide(
          slideIndex + 1
        ),
      5000
    );
  }

  // ----- FINALIZAR COMPRA -----
  document
    .getElementById(
      'finalizarCompra'
    )
    .addEventListener(
      'click',
      function() {
        if (carrinho.length === 0) {
          mostrarToast(
            'Seu carrinho está vazio'
          );

          return;
        }

        mostrarAba(
          'pagamento'
        );

        carrinhoOverlay.classList.remove(
          'aberto'
        );

        mostrarToast(
          'Finalize seu pedido'
        );
      }
    );

  // ----- TEMA -----
  const temaIcon =
    document.getElementById(
      'temaIcon'
    );

  function alternarTema() {
    document.body.classList.toggle(
      'tema-escuro'
    );

    const isDark =
      document.body.classList.contains(
        'tema-escuro'
      );

    temaIcon.className =
      isDark
        ? 'fas fa-sun'
        : 'fas fa-moon';

    localStorage.setItem(
      'tema',
      isDark
        ? 'escuro'
        : 'claro'
    );

    mostrarToast(
      isDark
        ? 'Modo escuro ativado'
        : 'Modo claro ativado'
    );
  }

  if (
    localStorage.getItem(
      'tema'
    ) === 'escuro'
  ) {
    document.body.classList.add(
      'tema-escuro'
    );

    temaIcon.className =
      'fas fa-sun';
  }

  temaIcon.addEventListener(
    'click',
    alternarTema
  );

  // ----- INICIALIZAR -----
  btnFiltrar.addEventListener(
    'click',
    aplicarFiltros
  );

  btnLimparFiltros.addEventListener(
    'click',
    limparFiltros
  );

  filtroTamanho.addEventListener(
    'change',
    aplicarFiltros
  );

  filtroCor.addEventListener(
    'change',
    aplicarFiltros
  );

  filtroPreco.addEventListener(
    'input',
    aplicarFiltros
  );

  atualizarCarrinho();

  renderProdutos(produtos);

  renderDestaque();

  mostrarAba('home');

  showSlide(0);

})();
